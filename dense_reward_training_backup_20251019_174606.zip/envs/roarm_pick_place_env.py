#!/usr/bin/env python3
"""
RoArm-M3 Pick and Place 강화학습 환경
Isaac Sim 5.0 + omni.isaac.lab 기반
"""

import numpy as np
import torch
from typing import Dict, Tuple

# Isaac Sim imports
import omni.isaac.core.utils.prims as prim_utils
from omni.isaac.core import World
from omni.isaac.core.objects import DynamicCuboid
from omni.isaac.core.articulations import Articulation
from omni.isaac.core.utils.stage import add_reference_to_stage
from pxr import Gf

# Isaac Lab imports (Isaac Sim 5.0)
try:
    from omni.isaac.lab.envs import DirectRLEnv, DirectRLEnvCfg
    from omni.isaac.lab.utils import configclass
except ImportError:
    # Fallback for older API
    print("⚠️ Isaac Lab API not found. Using basic implementation.")
    DirectRLEnv = object
    DirectRLEnvCfg = object
    configclass = lambda x: x


@configclass
class RoArmPickPlaceEnvCfg(DirectRLEnvCfg):
    """RoArm-M3 Pick and Place 환경 설정"""
    
    # Environment settings
    num_envs: int = 1
    env_spacing: float = 2.5
    episode_length_s: float = 10.0
    
    # Robot settings
    urdf_path: str = "/home/roarm_m3/roarm_isaac_clean/assets/roarm_m3/urdf/roarm_m3_multiprim.urdf"
    robot_position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    
    # Object settings
    object_position: Tuple[float, float, float] = (0.3, 0.0, 0.05)
    object_size: Tuple[float, float, float] = (0.04, 0.04, 0.04)
    target_position: Tuple[float, float, float] = (0.0, 0.3, 0.2)
    
    # Reward settings (Dense Reward - BALANCED SCALES)
    reach_reward_scale: float = 1.0      # End-effector → Cube (줄임: 5→1)
    grasp_reward: float = 5.0            # Grasping bonus (줄임: 10→5)
    lift_reward_scale: float = 2.0       # Lifting cube (줄임: 5→2)
    move_reward_scale: float = 2.0       # Cube → Target (줄임: 10→2)
    success_reward: float = 50.0         # Success bonus (줄임: 100→50)
    success_threshold: float = 0.05      # 5cm
    time_penalty: float = 0.01           # Efficiency penalty


class RoArmPickPlaceEnv:
    """
    RoArm-M3 Pick and Place 강화학습 환경 (Dense Reward)
    
    Task: 큐브를 집어서 타겟 위치로 옮기기
    
    Observation Space (25 dim):
        - Joint positions (6 dim): joint_1 ~ joint_6
        - Gripper state (2 dim): left_finger, right_finger positions
        - End-effector position (3 dim): x, y, z
        - Cube position (3 dim): x, y, z
        - Target position (3 dim): x, y, z
        - EE → Cube vector (3 dim): dx, dy, dz
        - Cube → Target vector (3 dim): dx, dy, dz
        - Gripper width (1 dim): distance between fingers
        - Is grasped (1 dim): 1.0 if grasping, 0.0 otherwise
    
    Action Space (8 dim):
        - Joint position deltas (6 dim): joint_1 ~ joint_6
        - Gripper position deltas (2 dim): left_finger, right_finger
    """
    
    def __init__(self, cfg: RoArmPickPlaceEnvCfg = None):
        """환경 초기화"""
        self.cfg = cfg if cfg else RoArmPickPlaceEnvCfg()
        
        # Isaac Sim World 초기화
        self.world = World(stage_units_in_meters=1.0)
        self.world.scene.add_default_ground_plane()
        
        print("=" * 60)
        print("🤖 RoArm-M3 Pick and Place Environment")
        print("=" * 60)
        
        # 로봇 로드
        self._load_robot()
        
        # 물체 생성
        self._create_objects()
        
        # 환경 변수 초기화
        self.current_step = 0
        self.max_steps = int(self.cfg.episode_length_s * 60)  # 60 FPS 가정
        
        # Observation/Action space 정의 (Dense Reward: 더 많은 정보)
        self.observation_space_dim = 25  # joint(8) + ee(3) + cube(3) + target(3) + ee2cube(3) + cube2target(3) + gripper_width(1) + is_grasped(1)
        self.action_space_dim = 8
        
        # 이전 상태 저장 (보상 계산용)
        self.prev_ee_to_cube_dist = None
        self.prev_cube_to_target_dist = None
        
        print(f"\n📊 환경 정보:")
        print(f"  - Observation dim: {self.observation_space_dim}")
        print(f"  - Action dim: {self.action_space_dim}")
        print(f"  - Max steps: {self.max_steps}")
        print(f"  - Success threshold: {self.cfg.success_threshold}m")
    
    def _load_robot(self):
        """로봇 URDF 로드"""
        print(f"\n🔧 로봇 로딩: {self.cfg.urdf_path}")
        
        # URDF 임포트 (Isaac Sim 5.0 방식)
        import omni.kit.commands
        from isaacsim.asset.importer.urdf import _urdf  # ✅ Isaac Sim 5.0 모듈!
        
        import_config = _urdf.ImportConfig()
        import_config.merge_fixed_joints = False
        import_config.fix_base = True
        import_config.import_inertia_tensor = True
        import_config.self_collision = False
        import_config.distance_scale = 1.0
        
        # URDF 임포트 (Isaac Sim 5.0 공식 방식)
        # ✅ URDFParseAndImportFile는 stage에 직접 import하며 prim_path를 반환
        print("  ⏳ URDF 파싱 중...")
        
        success, prim_path = omni.kit.commands.execute(
            "URDFParseAndImportFile",
            urdf_path=self.cfg.urdf_path,
            import_config=import_config,
            get_articulation_root=True,  # ✅ 공식 예제 패턴!
        )
        
        if not success:
            raise RuntimeError(f"❌ URDF 임포트 실패: {self.cfg.urdf_path}")
        
        print(f"  ✅ 로봇 임포트 성공!")
        print(f"  � Prim path: {prim_path}")
        
        # Articulation 생성 (반환된 prim_path 사용)
        self.robot = self.world.scene.add(
            Articulation(prim_path=prim_path, name="roarm_m3")
        )
        
        # World reset으로 articulation 초기화
        print(f"  ⏳ Articulation 초기화 중...")
        self.world.reset()
        
        # Joint 이름 가져오기
        self.joint_names = self.robot.dof_names
        print(f"  ✅ Joints ({len(self.joint_names) if self.joint_names else 0}): {self.joint_names[:3] if self.joint_names and len(self.joint_names) > 3 else self.joint_names}...")
        
        # ✅ Joint drive 설정 (USD API 사용)
        print(f"  ⏳ Joint drive 설정 중...")
        from pxr import UsdPhysics, PhysxSchema
        stage = self.world.stage
        
        # 모든 joint에 대해 drive 설정
        for i, joint_name in enumerate(self.joint_names):
            joint_prim = stage.GetPrimAtPath(f"{prim_path}/{joint_name}")
            if joint_prim and joint_prim.IsValid():
                # Drive API 적용 (완화된 값으로 부드러운 움직임)
                drive_api = UsdPhysics.DriveAPI.Apply(joint_prim, "angular")
                if i < 6:  # 팔 joint (완화: 10000 → 5000)
                    drive_api.GetStiffnessAttr().Set(5000.0)  # 완화
                    drive_api.GetDampingAttr().Set(500.0)     # 완화
                    drive_api.GetMaxForceAttr().Set(500.0)    # 완화
                else:  # 그리퍼
                    drive_api.GetStiffnessAttr().Set(1000.0)
                    drive_api.GetDampingAttr().Set(100.0)
                    drive_api.GetMaxForceAttr().Set(100.0)
        
        print(f"  ✅ Joint drive 설정 완료! (완화된 값)")
    
    def _create_objects(self):
        """물체 및 타겟 생성"""
        print(f"\n📦 물체 생성 중...")
        
        # 큐브 생성 (Pick 대상)
        self.cube = self.world.scene.add(
            DynamicCuboid(
                prim_path="/World/cube",
                name="cube",
                position=np.array(self.cfg.object_position),
                size=self.cfg.object_size[0],  # 정육면체
                color=np.array([0.8, 0.2, 0.2]),  # 빨간색
            )
        )
        print(f"  ✅ 큐브 생성: {self.cfg.object_position}")
        
        # 타겟 마커 생성 (시각적 목표)
        self.target = self.world.scene.add(
            DynamicCuboid(
                prim_path="/World/target",
                name="target",
                position=np.array(self.cfg.target_position),
                size=self.cfg.object_size[0],
                color=np.array([0.2, 0.8, 0.2]),  # 초록색
            )
        )
        # 타겟은 정적 (kinematic)으로 설정
        self.target.set_default_state(position=np.array(self.cfg.target_position))
        
        print(f"  ✅ 타겟 생성: {self.cfg.target_position}")
    
    def reset(self) -> np.ndarray:
        """환경 리셋"""
        print(f"\n🔄 환경 리셋 (Step {self.current_step})")
        
        # World 리셋
        self.world.reset()
        
        # 로봇 초기 자세 (Home position) - 약간 위로 올린 자세
        # 중력에 의해 떨어지지 않도록 안정적인 자세
        home_positions = np.array([0.0, -0.5, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0])  # 8 DOF
        self.robot.set_joint_positions(home_positions)
        self.robot.set_joint_velocities(np.zeros(8))
        
        # Physics 스텝 실행하여 안정화
        for _ in range(10):
            self.world.step(render=False)
        
        # 큐브 위치 랜덤화 (약간의 변화)
        cube_pos = np.array(self.cfg.object_position)
        cube_pos[:2] += np.random.uniform(-0.05, 0.05, size=2)  # X, Y ±5cm
        self.cube.set_world_pose(position=cube_pos)
        self.cube.set_linear_velocity(np.zeros(3))
        self.cube.set_angular_velocity(np.zeros(3))
        
        # 스텝 카운터 초기화
        self.current_step = 0
        
        # 이전 거리 초기화 (보상 계산용)
        self.prev_ee_to_cube_dist = None
        self.prev_cube_to_target_dist = None
        
        # 초기 observation 반환
        return self._get_observation()
    
    def _get_observation(self) -> np.ndarray:
        """현재 상태 관측 (Dense Reward: 더 많은 정보)"""
        # Joint positions (6 revolute + 2 prismatic)
        joint_positions = self.robot.get_joint_positions()[:8]
        
        # End-effector position
        ee_pos = self._get_ee_position()
        
        # Cube position
        cube_pos, _ = self.cube.get_world_pose()
        
        # Target position
        target_pos = np.array(self.cfg.target_position)
        
        # EE → Cube vector
        ee_to_cube = cube_pos - ee_pos
        
        # Cube → Target vector
        cube_to_target = target_pos - cube_pos
        
        # Gripper width (distance between fingers)
        gripper_width = joint_positions[6] + joint_positions[7]
        
        # Is grasped (간단한 휴리스틱: EE가 큐브 가까이 + 그리퍼 닫힘)
        ee_to_cube_dist = np.linalg.norm(ee_to_cube)
        is_grasped = 1.0 if (ee_to_cube_dist < 0.08 and gripper_width < 0.02) else 0.0
        
        # Observation 벡터 생성 (25 dim)
        obs = np.concatenate([
            joint_positions[:6],      # Joint positions (6)
            joint_positions[6:8],     # Gripper state (2)
            ee_pos,                   # EE position (3)
            cube_pos,                 # Cube position (3)
            target_pos,               # Target position (3)
            ee_to_cube,               # EE → Cube vector (3)
            cube_to_target,           # Cube → Target vector (3)
            [gripper_width],          # Gripper width (1)
            [is_grasped],             # Is grasped (1)
        ])
        
        return obs
    
    def _get_ee_position(self) -> np.ndarray:
        """End-effector 위치 계산 (간단한 forward kinematics)"""
        # 실제로는 robot.get_link_world_pose()를 사용해야 하지만
        # 여기서는 간단히 joint 값 기반으로 근사
        joint_positions = self.robot.get_joint_positions()
        
        # 베이스에서 시작
        z_base = 0.06  # base_link height
        z_link1 = 0.08  # link_1 height
        
        # Joint 2-4는 수평 암 (link_2, link_3, link_4)
        link2_length = 0.16
        link3_length = 0.15
        
        # 간단히 X축 방향으로 투영 (실제는 더 복잡)
        x_reach = link2_length * np.cos(joint_positions[1]) + \
                  link3_length * np.cos(joint_positions[1] + joint_positions[2])
        
        z_reach = z_base + z_link1 + \
                  link2_length * np.sin(joint_positions[1]) + \
                  link3_length * np.sin(joint_positions[1] + joint_positions[2])
        
        # Joint 1은 Z축 회전
        y_offset = x_reach * np.sin(joint_positions[0])
        x_offset = x_reach * np.cos(joint_positions[0])
        
        return np.array([x_offset, y_offset, z_reach])
    
    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, Dict]:
        """환경 스텝 실행"""
        # Action: joint position deltas (8 dim)
        action = np.clip(action, -1.0, 1.0)  # [-1, 1] 범위로 제한
        
        # 현재 joint positions 가져오기
        current_positions = self.robot.get_joint_positions()
        
        # Position delta 스케일링 (작은 움직임)
        max_deltas = np.array([0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.005, 0.005])
        position_deltas = action * max_deltas
        
        # 새로운 목표 위치 계산
        target_positions = current_positions + position_deltas
        
        # Joint limits 적용
        target_positions = np.clip(
            target_positions,
            [-3.14, -1.57, -1.57, -3.14, -3.14, -3.14, 0.0, 0.0],  # lower limits
            [3.14, 1.57, 1.57, 3.14, 3.14, 3.14, 0.04, 0.04]  # upper limits
        )
        
        # 로봇에 position 명령 전송 (직접 설정)
        self.robot.set_joint_positions(target_positions)
        
        # Physics 시뮬레이션 스텝
        self.world.step(render=True)
        
        # 현재 상태 관측
        obs = self._get_observation()
        
        # Reward 계산
        reward = self._calculate_reward(obs)
        
        # 종료 조건 확인
        done = self._check_done(obs)
        
        # 스텝 카운터 증가
        self.current_step += 1
        
        # Info 딕셔너리
        info = {
            "step": self.current_step,
            "cube_position": obs[9:12],
            "distance_to_target": obs[14],
        }
        
        return obs, reward, done, info
    
    def _calculate_reward(self, obs: np.ndarray) -> float:
        """
        Dense Reward 함수 (학습을 위해 세밀한 보상)
        
        Reward 구성:
        1. Reach: End-effector가 큐브에 가까워질수록 보상
        2. Grasp: 큐브를 잡으면 보상
        3. Lift: 큐브를 들어올리면 보상
        4. Move: 큐브가 목표에 가까워질수록 보상
        5. Success: 목표 도달 시 큰 보상
        6. Time: 효율성을 위한 작은 패널티
        """
        # 관찰에서 필요한 값 추출
        ee_pos = obs[8:11]
        cube_pos = obs[11:14]
        target_pos = obs[14:17]
        ee_to_cube_vec = obs[17:20]
        cube_to_target_vec = obs[20:23]
        is_grasped = obs[24]
        
        # 거리 계산
        ee_to_cube_dist = np.linalg.norm(ee_to_cube_vec)
        cube_to_target_dist = np.linalg.norm(cube_to_target_vec)
        
        # 1. Reach Reward: EE가 큐브에 접근
        reach_reward = -ee_to_cube_dist * self.cfg.reach_reward_scale
        
        # 이전 거리와 비교하여 개선 보상 (작은 값으로 수정)
        if self.prev_ee_to_cube_dist is not None:
            if ee_to_cube_dist < self.prev_ee_to_cube_dist:
                reach_reward += 0.05  # 가까워지면 추가 보상 (0.5 → 0.05)
        self.prev_ee_to_cube_dist = ee_to_cube_dist
        
        # 2. Grasp Reward: 큐브를 잡으면
        grasp_reward = is_grasped * self.cfg.grasp_reward
        
        # 3. Lift Reward: 큐브를 들어올리면
        lift_reward = 0.0
        if is_grasped and cube_pos[2] > 0.1:  # Z > 0.1m (들어올림)
            lift_reward = (cube_pos[2] - 0.05) * self.cfg.lift_reward_scale
        
        # 4. Move Reward: 큐브가 목표에 접근
        move_reward = -cube_to_target_dist * self.cfg.move_reward_scale
        
        # 이전 거리와 비교하여 개선 보상 (작은 값으로 수정)
        if self.prev_cube_to_target_dist is not None:
            if cube_to_target_dist < self.prev_cube_to_target_dist:
                move_reward += 0.1  # 가까워지면 추가 보상 (1.0 → 0.1)
        self.prev_cube_to_target_dist = cube_to_target_dist
        
        # 5. Success Reward: 목표 도달
        success_reward = 0.0
        if cube_to_target_dist < self.cfg.success_threshold:
            success_reward = self.cfg.success_reward
        
        # 6. Time Penalty: 효율성
        time_penalty = -self.cfg.time_penalty
        
        # 총 보상
        total_reward = (
            reach_reward +
            grasp_reward +
            lift_reward +
            move_reward +
            success_reward +
            time_penalty
        )
        
        return total_reward
    
    def _check_done(self, obs: np.ndarray) -> bool:
        """에피소드 종료 조건"""
        # 큐브 위치
        cube_pos = obs[11:14]
        
        # Cube → Target 거리
        cube_to_target_vec = obs[20:23]
        cube_to_target_dist = np.linalg.norm(cube_to_target_vec)
        
        # 타겟 도달
        if cube_to_target_dist < self.cfg.success_threshold:
            print(f"  ✅ SUCCESS! Distance: {cube_to_target_dist:.3f}m")
            return True
        
        # 최대 스텝 도달
        if self.current_step >= self.max_steps:
            print(f"  ⏱️ Timeout (Max steps: {self.max_steps})")
            return True
        
        # 물체가 테이블 밖으로 떨어짐 (Z < 0)
        if cube_pos[2] < -0.1:
            print(f"  ❌ Cube fell off table (Z: {cube_pos[2]:.3f}m)")
            return True
        
        return False
    
    def render(self):
        """렌더링 (Isaac Sim에서 자동 처리)"""
        pass
    
    def close(self):
        """환경 종료"""
        print("\n🛑 환경 종료")
        self.world.stop()


# 간단한 테스트
if __name__ == "__main__":
    print("🚀 RoArm-M3 Pick and Place 환경 테스트\n")
    
    # 환경 생성
    cfg = RoArmPickPlaceEnvCfg()
    cfg.episode_length_s = 5.0  # 짧게 테스트
    
    env = RoArmPickPlaceEnv(cfg)
    
    # 몇 에피소드 테스트
    for episode in range(2):
        print(f"\n{'='*60}")
        print(f"Episode {episode + 1}")
        print(f"{'='*60}")
        
        obs = env.reset()
        print(f"Initial observation shape: {obs.shape}")
        
        done = False
        total_reward = 0
        step = 0
        
        while not done and step < 100:
            # 랜덤 액션
            action = np.random.uniform(-0.5, 0.5, size=8)
            
            obs, reward, done, info = env.step(action)
            total_reward += reward
            step += 1
            
            if step % 20 == 0:
                print(f"  Step {step}: Reward={reward:.2f}, Distance={info['distance_to_target']:.3f}m")
        
        print(f"\n  📊 Episode {episode + 1} 결과:")
        print(f"    - Total steps: {step}")
        print(f"    - Total reward: {total_reward:.2f}")
        print(f"    - Final distance: {info['distance_to_target']:.3f}m")
    
    env.close()
    print("\n✅ 테스트 완료!")
